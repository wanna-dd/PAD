# Assets for PAD README

Place these files under the repository path:

PAD/
└── assets/
    ├── pad_banner.png
    ├── pad_framework.png
    └── results_overview.png

Recommended Markdown usage:

<p align="center">
  <img src="assets/pad_banner.png" width="850">
</p>

<p align="center">
  <img src="assets/pad_framework.png" width="850">
</p>

<p align="center">
  <img src="assets/results_overview.png" width="850">
</p>
